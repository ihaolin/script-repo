from distutils.core import setup

setup(
	name			= 'athletelist',
	version 		= '1.3.2',
	py_modules 		= ['athletelist'],
	author 			= 'linhao',
	author_email 	= '576240289@qq.com',
	url 			= 'http://www.baidu.com',
	description		= 'A class inherits from list',
)