from distutils.core import setup

setup(
	name			= 'nester',
	version 		= '1.0.0',
	py_modules 		= ['nester'],
	author 			= 'linhao',
	author_email 	= '576240289@qq.com',
	url 			= 'http://www.baidu.com',
	description		= 'A simple printer of nester lists',
)